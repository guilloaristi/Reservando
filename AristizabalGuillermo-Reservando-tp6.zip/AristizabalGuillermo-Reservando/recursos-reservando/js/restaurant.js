var Restaurant = function(id, nombre, rubro, ubicacion, horarios, imagen, calificaciones, precioPorPersona) {
    this.id = id;
    this.nombre = nombre;
    this.rubro = rubro;
    this.ubicacion = ubicacion;
    this.horarios = horarios;
    this.imagen = imagen;
    this.calificaciones = calificaciones;
    this.precioPorPersona = precioPorPersona;
}


//GUIA 2 -PASO 1 FILTER()

//INICIAL ERA ESTA
// Restaurant.prototype.reservarHorario = function(horarioReservado) {
//     for (var i = 0; i < this.horarios.length; i++) {
//         if (this.horarios[i] === horarioReservado) {
//             this.horarios.splice(i, 1);
//             return;
//         }
//     }
// }

Restaurant.prototype.reservarHorario = function(horarioReservado) {
    var nuevosHorarios = this.horarios.filter(function(horario) {
        return horario !== horarioReservado;
    });
    //Cambio horarios del restaurant por nuevos horarios
    this.horarios = nuevosHorarios;
}


Restaurant.prototype.calificar = function(nuevaCalificacion) {
    if (Number.isInteger(nuevaCalificacion) && nuevaCalificacion > 0 && nuevaCalificacion < 10) {
        this.calificaciones.push(nuevaCalificacion);
    }
}


//GUIA 2 PASO 2 REFACTOREAR ESTA FUNCION.

// Restaurant.prototype.obtenerPuntuacion = function() {
//     if (this.calificaciones.length === 0) {
//         return 0;
//     } else {
//         var sumatoria = 0;
//         for (var i = 0; i < this.calificaciones.length; i++) {
//             sumatoria += this.calificaciones[i]
//         }
//         var promedio = sumatoria / this.calificaciones.length;
//         return Math.round(promedio * 10) / 10;
//     }

// }

//---revisar .reduce-----
var sumatoriaDeArray = function(arrayNumeros) {
    return arrayNumeros.reduce(function(acum, newValue) { return acum + newValue; });
}

var promedioDeArray = function(array) {
    return sumatoriaDeArray(array) / array.length;

}

Restaurant.prototype.obtenerPuntuacion = function() {
    if (this.calificaciones.length === 0) {
        return 0;
    }

    return Math.round(promedioDeArray(this.calificaciones) * 10) / 10;
}